package com.example.second_ind.data

data class Auto(val text1: String, val text2: String, val text3: String, val text4: String)
